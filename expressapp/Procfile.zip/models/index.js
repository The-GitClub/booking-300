module.exports = {
    Bookings: require("./booking"),
    Restaurant: require("./restaurant")
    // ,
    // user: require("./user"),
  };
  